package org.jsp.ebanking;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbankingApplicationTests {

}

