package org.jsp.ebanking.dto;

public enum BankingRole {
	ADMIN, USER
}
