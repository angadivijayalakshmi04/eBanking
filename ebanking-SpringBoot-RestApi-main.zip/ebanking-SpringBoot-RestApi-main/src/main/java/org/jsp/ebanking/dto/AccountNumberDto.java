package org.jsp.ebanking.dto;

import lombok.Data;

@Data
public class AccountNumberDto {
	private Long accountNumber;
}
